﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using zjh.SSLY.Model.Info;

namespace zjh.SSLY.UI.MvcMain.Controllers
{
    public class BillGoodsReceiptController : Controller
    {
        zjh.SSLY.IBLL.Info.IBillGoodsReceiptHdrService bllHdr = new BLL.Info.BillGoodsReceiptHdrService();
        zjh.SSLY.IBLL.Info.IBillGoodsReceiptDtlService bllDtl = new BLL.Info.BillGoodsReceiptDtlService();

        //GET: /BillGoodsReceipt/

        public ActionResult Index()
        {
            return View();
        }
        #region crud
        public ActionResult Save(BillGoodsReceiptHdr Model, List<BillGoodsReceiptDtl> dtls)
        {
            //if (Model.ID > 0)
            //{
            //    var hdrs = bllHdr.LoadEntities(u => u.Formno == Model.Formno).ToList();
            //    if (hdrs.Count > 0)
            //    {
            //        hdrs[0].Description = Model.Description;
            //        hdrs[0].Uid = 0;
            //        hdrs[0].CreateTime = DateTime.Now;
            //        hdrs[0].PFormno = "/";
            //        hdrs[0].Freight = 0;
            //        hdrs[0].Active = true;
            //        hdrs[0].CheckDate = DateTime.Now;
            //        hdrs[0].Checker = 0;
            //        hdrs[0].CheckState = "已审核";
            //        hdrs[0].State = 0;
            //        hdrs[0].WHID = "GZ";
            //        hdrs[0].SupplierID = "15000001";
            //        bool result = bllHdr.UpdateEntity(hdrs[0]);
            //        if (result)
            //        {
            //            return Content("Ok");
            //        }
            //    }
            //}
            //else
            //{

            //    bllHdr.Save(Model, new List<BillGoodsReceiptDtl>());
            //    return Content("Ok");
            //}
            return Content("Error");
        }

        //根据订单状态加载视图 
        public ActionResult LoadView()
        {
            var pageSize = int.Parse(Request["rows"] ?? "30");
            var pageIndex = int.Parse(Request["page"] ?? "1");
            int totalCount = 0;
            List<BillGoodsReceiptHdr> tmp = bllHdr.LoadPageEntities(u => u.ID > 0, pageIndex, pageSize, out totalCount, r => r.CreateTime, false).ToList();
            var data = new { total = totalCount, rows = tmp };
            return Json(data);
        }

        //根据订单状态加载视图 
        public ActionResult LoadDtl(string formno)
        {
            List<BillGoodsReceiptDtl> tmp = bllDtl.LoadEntities(u => u.Formno == formno).ToList();
            var data = new { total = tmp.Count, rows = tmp };
            return Json(data);
        }


        [HttpPost]
        public ActionResult SaveHdr(BillGoodsReceiptHdr Model)
        {
            //if (Model.ID > 0)
            //{
            //    var hdrs = bllHdr.LoadEntities(u => u.ID == Model.ID).ToList();
            //    if (hdrs.Count > 0)
            //    {
            //        bool result = bllHdr.UpdateEntity(hdrs[0]);
            //        if (result)
            //        {
            //            return Content("Ok");
            //        }
            //    }
            //}
            //else
            //{
            //    bllHdr.Save(Model, new List<BillGoodsReceiptDtl>());
            //    return Content("Ok");
            //}
            return Content("Error");
        }

        public ActionResult SaveDtl(BillGoodsReceiptDtl Model)
        {
            if (Model.ID > 0)
            {
                var dtls = bllDtl.LoadEntities(u => u.ID == Model.ID).ToList();
                if (dtls.Count > 0)
                {
                    bool result = bllDtl.UpdateEntity(dtls[0]);
                    if (result)
                    {
                        return Content("Ok");
                    }
                }
            }
            else
            {
                bllDtl.AddEntity(Model);
                return Content("Ok");
            }
            return Content("Error");
        }
        #endregion

    }
}
